package com.request.validation

class APIResponse {

	String statusCode
	String error
	
}
