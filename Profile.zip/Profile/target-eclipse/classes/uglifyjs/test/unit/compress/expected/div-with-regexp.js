print(a/ /[a-z]/)
