package com.profile.exception

class ProfileError {
	
	 String httpCode
	 String errorDetails
	
	 
}
