import grails.rest.render.xml.XmlRenderer

import com.applicant.profile.Profile

// Place your Spring DSL code here
beans = {

}
