package com.profile.exception;

public class ProfileException extends RuntimeException{
 
	ProfileError profileError;
	
	
	  
}
