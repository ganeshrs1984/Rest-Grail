package com.applicant.profile

class Experience {
	static belongsTo = [profile: Profile]
	String client	
	float exp
    String tech
	
	
}




